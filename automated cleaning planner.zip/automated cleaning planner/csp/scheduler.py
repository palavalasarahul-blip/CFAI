"""CSP cleaning scheduler with systematic and local-search solvers."""

from __future__ import annotations

import random
from collections import defaultdict
from dataclasses import dataclass, field

from environment.models import CleaningTask


@dataclass
class ScheduleResult:
    assignments: dict[str, int]
    success: bool
    failures: list[str] = field(default_factory=list)
    method: str = "Backtracking + Forward Checking"
    consistency_checks: int = 0

    @property
    def quality(self) -> float:
        if not self.assignments:
            return 0.0
        conflicts = len(self.failures)
        return max(0.0, 100.0 - conflicts * 15.0)


class CSPScheduler:
    """Assigns cleaning tasks to hourly slots while enforcing constraints."""

    def __init__(
        self,
        tasks: list[CleaningTask],
        battery_capacity: float = 100.0,
        maintenance_slots: set[int] | None = None,
        slot_capacity: int = 1,
    ) -> None:
        self.tasks = {task.room_name: task for task in tasks}
        self.battery_capacity = battery_capacity
        self.maintenance_slots = maintenance_slots or {13}
        self.slot_capacity = slot_capacity
        self.checks = 0
        self.failure_reasons: list[str] = []
        self.domains = {
            name: sorted(task.available_slots - self.maintenance_slots)
            for name, task in self.tasks.items()
        }

    def solve(self) -> ScheduleResult:
        self.checks = 0
        self.failure_reasons = []
        domains = {name: list(values) for name, values in self.domains.items()}
        if not self._enforce_arc_consistency(domains):
            return ScheduleResult(
                {}, False, self.failure_reasons, consistency_checks=self.checks
            )
        assignment = self._backtrack({}, domains)
        if assignment is None:
            if not self.failure_reasons:
                self.failure_reasons.append(
                    "No complete assignment satisfies battery, duration, availability, "
                    "priority, and maintenance constraints."
                )
            return ScheduleResult(
                {}, False, self._unique_failures(), consistency_checks=self.checks
            )
        for name, slot in assignment.items():
            self.tasks[name].assigned_slot = slot
        return ScheduleResult(
            assignment,
            True,
            self._unique_failures(),
            consistency_checks=self.checks,
        )

    def _backtrack(
        self,
        assignment: dict[str, int],
        domains: dict[str, list[int]],
    ) -> dict[str, int] | None:
        if len(assignment) == len(self.tasks):
            return assignment
        variable = self._select_unassigned_variable(assignment, domains)
        for value in self._order_domain_values(variable, assignment, domains):
            if not self._is_consistent(variable, value, assignment):
                continue
            updated = dict(assignment)
            updated[variable] = value
            reduced = self._forward_check(variable, value, updated, domains)
            if reduced is not None:
                result = self._backtrack(updated, reduced)
                if result is not None:
                    return result
        return None

    def _select_unassigned_variable(
        self, assignment: dict[str, int], domains: dict[str, list[int]]
    ) -> str:
        candidates = [name for name in self.tasks if name not in assignment]
        # MRV first, degree/priority second.
        return min(
            candidates,
            key=lambda name: (
                len(domains[name]),
                -self._degree(name, candidates),
                -self.tasks[name].priority,
            ),
        )

    def _degree(self, name: str, candidates: list[str]) -> int:
        slots = set(self.domains[name])
        return sum(
            bool(slots & set(self.domains[other]))
            for other in candidates
            if other != name
        )

    def _order_domain_values(
        self,
        variable: str,
        assignment: dict[str, int],
        domains: dict[str, list[int]],
    ) -> list[int]:
        # LCV: prefer values that remove the fewest options from neighbors.
        others = [
            name for name in self.tasks
            if name not in assignment and name != variable
        ]
        return sorted(
            domains[variable],
            key=lambda value: sum(value in domains[name] for name in others),
        )

    def _is_consistent(
        self, variable: str, value: int, assignment: dict[str, int]
    ) -> bool:
        self.checks += 1
        task = self.tasks[variable]
        if value in self.maintenance_slots:
            self.failure_reasons.append(
                f"{variable} cannot start at {value}:00 because maintenance is scheduled."
            )
            return False
        overlaps = [
            name for name, start in assignment.items()
            if self._overlap(value, task.duration, start, self.tasks[name].duration)
        ]
        if len(overlaps) >= self.slot_capacity:
            self.failure_reasons.append(
                f"{variable} at {value}:00 conflicts with {', '.join(overlaps)}."
            )
            return False
        used_battery = sum(self.tasks[name].battery_cost for name in assignment)
        if used_battery + task.battery_cost > self.battery_capacity:
            self.failure_reasons.append(
                f"{variable} exceeds the {self.battery_capacity:.0f}% battery budget."
            )
            return False
        # Higher-priority rooms should not be scheduled after lower-priority rooms
        # when both could use the earlier slot.
        for name, start in assignment.items():
            other = self.tasks[name]
            if task.priority > other.priority and value > start:
                if value in other.available_slots and start in task.available_slots:
                    return False
        return True

    @staticmethod
    def _overlap(start_a: int, duration_a: int, start_b: int, duration_b: int) -> bool:
        return start_a < start_b + duration_b and start_b < start_a + duration_a

    def _forward_check(
        self,
        variable: str,
        value: int,
        assignment: dict[str, int],
        domains: dict[str, list[int]],
    ) -> dict[str, list[int]] | None:
        reduced = {name: list(values) for name, values in domains.items()}
        reduced[variable] = [value]
        for name in self.tasks:
            if name in assignment:
                continue
            valid = [
                candidate
                for candidate in reduced[name]
                if self._is_consistent(name, candidate, assignment)
            ]
            if not valid:
                self.failure_reasons.append(
                    f"Forward checking removed every available slot for {name}."
                )
                return None
            reduced[name] = valid
        return reduced

    def _enforce_arc_consistency(self, domains: dict[str, list[int]]) -> bool:
        """AC-3 intuition: remove values with no non-overlapping support."""
        queue = [
            (left, right)
            for left in self.tasks
            for right in self.tasks
            if left != right
        ]
        while queue:
            left, right = queue.pop(0)
            revised = False
            supported: list[int] = []
            for left_value in domains[left]:
                has_support = any(
                    not self._overlap(
                        left_value,
                        self.tasks[left].duration,
                        right_value,
                        self.tasks[right].duration,
                    )
                    for right_value in domains[right]
                )
                if has_support:
                    supported.append(left_value)
                else:
                    revised = True
            if revised:
                domains[left] = supported
                if not supported:
                    self.failure_reasons.append(
                        f"Arc consistency found no supported time for {left}."
                    )
                    return False
                queue.extend(
                    (neighbor, left)
                    for neighbor in self.tasks
                    if neighbor not in {left, right}
                )
        return True

    def min_conflicts(
        self, max_steps: int = 1000, seed: int = 42
    ) -> ScheduleResult:
        rng = random.Random(seed)
        if any(not domain for domain in self.domains.values()):
            return ScheduleResult({}, False, ["At least one task has an empty domain."], "Min-Conflicts")
        assignment = {
            name: rng.choice(domain) for name, domain in self.domains.items()
        }
        for step in range(max_steps):
            conflicted = [
                name for name in self.tasks
                if self._conflict_count(name, assignment[name], assignment) > 0
            ]
            if not conflicted:
                return ScheduleResult(assignment, True, method="Min-Conflicts", consistency_checks=step)
            variable = rng.choice(conflicted)
            scores = {
                value: self._conflict_count(variable, value, assignment)
                for value in self.domains[variable]
            }
            best = min(scores.values())
            assignment[variable] = rng.choice(
                [value for value, score in scores.items() if score == best]
            )
        conflicts = self.detect_conflicts(assignment)
        return ScheduleResult(
            assignment,
            False,
            conflicts or ["Min-conflicts reached its step limit."],
            "Min-Conflicts",
            max_steps,
        )

    def _conflict_count(
        self, variable: str, value: int, assignment: dict[str, int]
    ) -> int:
        task = self.tasks[variable]
        count = int(value in self.maintenance_slots)
        for name, start in assignment.items():
            if name == variable:
                continue
            count += int(
                self._overlap(value, task.duration, start, self.tasks[name].duration)
            )
        total_battery = sum(task.battery_cost for task in self.tasks.values())
        count += int(total_battery > self.battery_capacity)
        return count

    def detect_conflicts(self, assignment: dict[str, int]) -> list[str]:
        conflicts: list[str] = []
        occupancy: defaultdict[int, list[str]] = defaultdict(list)
        for name, start in assignment.items():
            for hour in range(start, start + self.tasks[name].duration):
                occupancy[hour].append(name)
            if start not in self.tasks[name].available_slots:
                conflicts.append(f"{name} is unavailable at {start}:00.")
            if start in self.maintenance_slots:
                conflicts.append(f"{name} overlaps maintenance at {start}:00.")
        for hour, names in occupancy.items():
            if len(names) > self.slot_capacity:
                conflicts.append(f"{hour}:00 is overbooked by {', '.join(names)}.")
        if sum(task.battery_cost for task in self.tasks.values()) > self.battery_capacity:
            conflicts.append("The complete schedule exceeds the battery budget.")
        return conflicts

    def _unique_failures(self) -> list[str]:
        return list(dict.fromkeys(self.failure_reasons))[-8:]

