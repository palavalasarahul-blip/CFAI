"""Collection and reporting of cleaning simulation metrics."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd


@dataclass
class AnalyticsTracker:
    initial_dirt: int
    initial_battery: float = 100.0
    started_at: datetime = field(default_factory=datetime.now)
    events: list[dict[str, object]] = field(default_factory=list)
    predictions: list[tuple[float, bool]] = field(default_factory=list)

    def record(
        self,
        action: str,
        battery: float,
        cleaned_cells: int,
        room: str | None = None,
    ) -> None:
        self.events.append(
            {
                "Step": len(self.events) + 1,
                "Action": action,
                "Battery": battery,
                "Cleaned Cells": cleaned_cells,
                "Room": room or "-",
                "Elapsed (s)": (datetime.now() - self.started_at).total_seconds(),
            }
        )

    def add_prediction(self, probability: float, actual_dirty: bool) -> None:
        self.predictions.append((probability, actual_dirty))

    def summary(self, battery: float, cleaned_cells: int) -> dict[str, float]:
        elapsed = max(0.001, (datetime.now() - self.started_at).total_seconds())
        area = float(cleaned_cells)
        consumed = self.initial_battery - battery
        efficiency = area / max(consumed, 1.0)
        accuracy = self.prediction_accuracy()
        return {
            "Total Area Cleaned": area,
            "Cleaning Efficiency": efficiency,
            "Battery Consumption": consumed,
            "Runtime": elapsed,
            "Prediction Accuracy": accuracy,
        }

    def prediction_accuracy(self) -> float:
        if not self.predictions:
            return 0.0
        correct = sum(
            (probability >= 0.5) == actual
            for probability, actual in self.predictions
        )
        return correct / len(self.predictions)

    def frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.events)

