"""Graph-backed dynamic grid environment."""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field

import networkx as nx

from .models import CellType, Position, Robot, Room

LOGGER = logging.getLogger(__name__)


@dataclass
class HouseEnvironment:
    width: int = 10
    height: int = 8
    rooms: dict[str, Room] = field(default_factory=dict)
    obstacles: set[Position] = field(default_factory=set)
    dirt: dict[Position, float] = field(default_factory=dict)
    chargers: set[Position] = field(default_factory=lambda: {(0, 0)})
    graph: nx.Graph = field(init=False)

    def __post_init__(self) -> None:
        if not self.rooms:
            self.rooms = self._default_rooms()
        self._validate_positions()
        self.rebuild_graph()

    @classmethod
    def demo(cls, seed: int = 7) -> "HouseEnvironment":
        environment = cls()
        environment.obstacles = {(2, 2), (2, 3), (5, 4), (6, 4), (8, 1)}
        rng = random.Random(seed)
        candidates = [
            p for p in environment.all_positions()
            if p not in environment.obstacles and p not in environment.chargers
        ]
        for position in rng.sample(candidates, 10):
            environment.dirt[position] = round(rng.uniform(0.35, 1.0), 2)
        environment.rebuild_graph()
        return environment

    def _default_rooms(self) -> dict[str, Room]:
        definitions = [
            ("Living Room", 0, 5, 0, 4, 3, "living"),
            ("Kitchen", 5, 10, 0, 4, 5, "kitchen"),
            ("Bedroom", 0, 5, 4, 8, 2, "bedroom"),
            ("Bathroom", 5, 8, 4, 8, 4, "bathroom"),
            ("Dining Hall", 8, 10, 4, 8, 3, "dining"),
        ]
        result: dict[str, Room] = {}
        for name, x0, x1, y0, y1, priority, room_type in definitions:
            cells = {(x, y) for x in range(x0, x1) for y in range(y0, y1)}
            result[name] = Room(
                name=name,
                cells=cells,
                priority=priority,
                room_type=room_type,
                cleaning_duration=1 if priority < 4 else 2,
            )
        return result

    def _validate_positions(self) -> None:
        invalid = {
            p for p in self.obstacles | self.chargers | set(self.dirt)
            if not self.in_bounds(p)
        }
        if invalid:
            raise ValueError(f"Positions outside grid: {sorted(invalid)}")

    def rebuild_graph(self) -> None:
        self.graph = nx.Graph()
        for position in self.all_positions():
            if position not in self.obstacles:
                self.graph.add_node(position)
        for x, y in self.graph.nodes:
            for neighbor in ((x + 1, y), (x, y + 1)):
                if neighbor in self.graph:
                    weight = 1.0 + self.dirt.get(neighbor, 0.0) * 0.2
                    self.graph.add_edge((x, y), neighbor, weight=weight)
        LOGGER.info(
            "Environment graph rebuilt with %d nodes and %d edges",
            self.graph.number_of_nodes(),
            self.graph.number_of_edges(),
        )

    def all_positions(self) -> list[Position]:
        return [(x, y) for y in range(self.height) for x in range(self.width)]

    def in_bounds(self, position: Position) -> bool:
        x, y = position
        return 0 <= x < self.width and 0 <= y < self.height

    def neighbors(self, position: Position) -> list[Position]:
        if position not in self.graph:
            return []
        return sorted(self.graph.neighbors(position))

    def room_at(self, position: Position) -> Room | None:
        return next((room for room in self.rooms.values() if room.contains(position)), None)

    def room_dirt(self, room_name: str) -> list[Position]:
        return sorted(self.rooms[room_name].cells & self.dirt.keys())

    def cell_type(self, position: Position) -> CellType:
        if position in self.obstacles:
            return CellType.OBSTACLE
        if position in self.chargers:
            return CellType.CHARGER
        return CellType.FLOOR

    def add_dirt(self, position: Position, intensity: float = 1.0) -> None:
        if position in self.obstacles or not self.in_bounds(position):
            raise ValueError("Dirt must be placed on a traversable grid cell.")
        self.dirt[position] = min(1.0, max(0.0, intensity))
        self.rebuild_graph()

    def clean(self, robot: Robot) -> bool:
        if robot.position not in self.dirt:
            robot.knowledge.record(f"No dirt detected at {robot.position}; cleaning skipped.")
            return False
        robot.clean(robot.position)
        del self.dirt[robot.position]
        self.rebuild_graph()
        return True

    def update_knowledge(self, robot: Robot) -> None:
        robot.knowledge.obstacles = set(self.obstacles)
        robot.knowledge.dirty_locations = set(self.dirt)
        robot.knowledge.visited_locations.add(robot.position)
        robot.knowledge.battery_level = robot.battery

    def peas(self) -> dict[str, list[str]]:
        return {
            "Performance": [
                "area cleaned",
                "time minimized",
                "energy conserved",
                "collisions avoided",
                "schedule adherence",
            ],
            "Environment": [
                "grid house",
                "rooms",
                "dynamic dirt",
                "obstacles",
                "charging stations",
                "occupants",
            ],
            "Actuators": ["wheel motors", "vacuum", "brush", "mop", "charger"],
            "Sensors": [
                "dirt sensor",
                "camera",
                "occupancy sensor",
                "battery monitor",
                "position sensor",
            ],
        }
